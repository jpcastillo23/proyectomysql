import java.awt.List;
import java.util.*;
import java.io.*;
import java.util.*;


public class Mis_pruebas_Jp {

	private static Mitable adios,prueb;
	public static String hola ;//= new String();
	public static Misqlobject hehe;

	public static void main(String[] args)  {
		/**String hola2="null";
		hehe = new Misqlobject(hola);
		System.out.println( hehe.isString() );
		/**   // */
		 String donde = "/Users/josecastillo/Netbeans/Mi_Sql_pequeño/MyDB/db_registry.txt";
		 
		File nuevo = new File(donde);
		DLL_manager manejador = new DLL_manager();
		manejador.Anadir_fila_fichero(donde, "que cancha");  // */
		
	}

}
